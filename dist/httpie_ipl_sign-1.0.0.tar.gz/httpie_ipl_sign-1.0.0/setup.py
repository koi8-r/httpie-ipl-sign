# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['httpie_ipl_sign']

package_data = \
{'': ['*']}

install_requires = \
['httpie>=3.2.1,<4.0.0', 'requests>=2.28.1,<3.0.0']

entry_points = \
{'httpie.plugins.auth.v1': ['ipl_sign = '
                            'httpie_ipl_sign.ipl_sign:IplSignPlugin']}

setup_kwargs = {
    'name': 'httpie-ipl-sign',
    'version': '1.0.0',
    'description': '',
    'long_description': '## Adds `api_key` and hmac `sign` to parameters of a query string\n\n### Install httpie\n```shell\n# Examples\napt install httpie\nbrew install httpie\npip install httpie\n```\n\n### Install plugin\n```shell\nhttpie cli plugins install \\\n  https://github.com/koi8-r/httpie-ipl-sign/raw/master/dist/httpie_ipl_sign-1.0.0-py3-none-any.whl\n# or directly from https://github.com/koi8-r/httpie-ipl-sign/archive/refs/heads/master.zip\n```\n\n### Use\n```shell\nhttp -v -A ipl-sign -a key:secret api.example.org\n```\n',
    'author': 'Valentin Nagornyy',
    'author_email': 'valentin.nagornyy@inplat.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
